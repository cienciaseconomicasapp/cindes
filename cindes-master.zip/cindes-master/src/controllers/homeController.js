

export const home = async (req, res) => {
 
     res.render('home')

}

export const  success = async (req, res) => {
     res.render('success', {layout:false})

}

export const  error = async (req, res) => {
     res.render('error', {layout:false})

}

export const login = async (req, res) => {

     res.render('login', {layout:false})
}

