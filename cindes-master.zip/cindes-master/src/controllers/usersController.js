    const {google} = require("googleapis")
    const path = require("path")
    const controller = {}

    controller.page = (req, res) => {

        res.render('users')

    }

    controller.getUsers = async (req, res) => {

        const auth = new google.auth.GoogleAuth({
            keyFile: 'src/json/credentials.json',
            scopes: "https://www.googleapis.com/auth/spreadsheets",
        })
    
        //Creat client instance for auth
        const client = await auth.getClient()
        
        //Instance of Google Sheets API
        const googleSheets = google.sheets({version: "v4", auth: client})
        const spreadsheetId = "1spbcKAewmtuHvL3mpHQFBrhxi5Q3GOMVzEZoNtqcEHM"
        
        //Get data about spreadsheets
        const metaData = await googleSheets.spreadsheets.values.get({
            auth,
            spreadsheetId,
            range: "users!A:F"
        })
        
        res.json( metaData.data )

    }

    controller.getTeacherUsers = async (req, res) => {

        const auth = new google.auth.GoogleAuth({
            keyFile: 'src/json/credentials.json',
            scopes: "https://www.googleapis.com/auth/spreadsheets",
        })
    
        //Creat client instance for auth
        const client = await auth.getClient()
        
        //Instance of Google Sheets API
        const googleSheets = google.sheets({version: "v4", auth: client})
        const spreadsheetId = "1spbcKAewmtuHvL3mpHQFBrhxi5Q3GOMVzEZoNtqcEHM"
        
        //Get data about spreadsheets
        const metaData = await googleSheets.spreadsheets.values.get({
            auth,
            spreadsheetId,
            range: "users!A:F"
        })
        
        const teachers = metaData.data.values.filter( teacher => teacher[5] === '1')

        //Organizamos alfabeticamente por nombre (position 3 into the array)
        teachers.sort( (a, b) => a[3] > b[3] ? 1 : -1)

        res.json( teachers )

    }

    controller.getUser = async (req, res) => {

        const { row } = req.body

        const auth = new google.auth.GoogleAuth({
            keyFile: 'src/json/credentials.json',
            scopes: "https://www.googleapis.com/auth/spreadsheets",
        })
    
        //Creat client instance for auth
        const client = await auth.getClient()
        
        //Instance of Google Sheets API
        const googleSheets = google.sheets({version: "v4", auth: client})
        const spreadsheetId = "1spbcKAewmtuHvL3mpHQFBrhxi5Q3GOMVzEZoNtqcEHM"
        
        //Get data about spreadsheets
        const metaData = await googleSheets.spreadsheets.values.get({
            auth,
            spreadsheetId,
            range: `users!A${row}:E${row}`
        })
        
        res.json( metaData.data )

    }

    controller.updateUser = async (req, res) => {
        
        const {name, username, role, row} = req.body

        const auth = new google.auth.GoogleAuth({
            keyFile: 'src/json/credentials.json',
            scopes: "https://www.googleapis.com/auth/spreadsheets",
        })
        
        //Creat client instance for auth
        const client = await auth.getClient()

        const googleSheets = google.sheets({version: "v4", auth: client})
        const spreadsheetId = "1spbcKAewmtuHvL3mpHQFBrhxi5Q3GOMVzEZoNtqcEHM"
        
        let request = {
            auth,        
            valueInputOption: "RAW",
            resource: {
                values: [
                    [
                        username,
                        role,
                        name
                    ]
                ]
            },
            spreadsheetId,
            range: `users!B${row}:D${row}`
        }


        try {

            const response = (await googleSheets.spreadsheets.values.update(request)).data 
            res.json({
                updated: true,
                message: 'Usuario actualizado.',
                response
            })
            
        } catch (err) {
            
            res.json( {
                updated : false,
                message : err
            } )

        }

    }
   
    controller.removeUser = async ( req, res ) => {

        const { row } = req.body

        const auth = new google.auth.GoogleAuth({
            keyFile: 'src/json/credentials.json',
            scopes: "https://www.googleapis.com/auth/spreadsheets",
        })
        
        //Creat client instance for auth
        const client = await auth.getClient()

        const googleSheets = google.sheets({version: "v4", auth: client})
        const spreadsheetId = "1spbcKAewmtuHvL3mpHQFBrhxi5Q3GOMVzEZoNtqcEHM"
        
        let request = {
            auth,        
            spreadsheetId,
            range: `users!A${row}:E${row}`
        }


        try {

            const response = (await googleSheets.spreadsheets.values.clear(request)).data 
            res.json({
                deleted: true,
                message: 'Usuario removido.',
                response
            })
            
        } catch (err) {
            
            res.json( {
                deleted : false,
                message : err
            } )

        }
        
    }

module.exports = controller