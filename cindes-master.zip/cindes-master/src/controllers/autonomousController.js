const {google} = require("googleapis")
const path = require("path")
const controller = {}

controller.page = (req, res) => {

    res.render('autonomous')

}


controller.getList = async (req, res) => {

    const { email } = req.body
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1JPh5BfqKw27j1cHnaP3ZI0d6LGc8uswBYAO83iWaTrM"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:Q"
     })

     metaData.data.values.forEach( (item,index)=>{
        metaData.data.values[index].push(index+1)
     })
     

     if( email === '' ) {
    
        res.json( metaData.data.values )

    } else {
        
        let data = metaData.data.values.filter( (item, index) => item[1] === email )
        console.log(data)
        res.json( data )

    }

}

controller.getRow = async (req, res) => {

    const { row } = req.body;

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1JPh5BfqKw27j1cHnaP3ZI0d6LGc8uswBYAO83iWaTrM"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.batchGet({
        auth,
         spreadsheetId,
         ranges: [
             'Respuestas de formulario 1!A1:A1',
             `Respuestas de formulario 1!A${row}:Q${row}`
         ]
     })
     
    res.json( metaData.data.valueRanges )

}

controller.changeStatus = async ( req, res ) => {

    let row = req.body.row,
        status = req.body.stateChange,
        observations = req.body.observations
        
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "1JPh5BfqKw27j1cHnaP3ZI0d6LGc8uswBYAO83iWaTrM"
   
    data = [
        {           
            range: `Respuestas de formulario 1!P${row}`,
            values: [[status]]
        },
        {
            range: `Respuestas de formulario 1!Q${row}`,
            values: [[observations]]
        }
    ]
 
    request = {

        auth,        
        valueInputOption: "RAW",
        resource: { data },
        spreadsheetId
        
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.batchUpdate(request)).data 
        console.log(JSON.stringify(response, null, 2))
        res.json( response )
        
    } catch (err) {
        
        console.error(err)
        res.json( 'error' )

    }
    
    
}

module.exports = controller