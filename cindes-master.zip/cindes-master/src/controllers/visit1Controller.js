const {google} = require("googleapis")
const path = require("path")
const controller = {}

controller.page = (req, res) => {

    res.render('visit1')

}


controller.getList = async (req, res) => {

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1QHMRqMwOFK_oxmbB8aLP25wAqelCmB2pytCC746CYyc"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Contad!A:AE"
     })
     
    res.json( metaData.data )

}

controller.getRow = async (req, res) => {

    const { row } = req.body;

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1QHMRqMwOFK_oxmbB8aLP25wAqelCmB2pytCC746CYyc"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.batchGet({
        auth,
         spreadsheetId,
         ranges: [
             'Contad!A1:A1',
             `Contad!A${row}:AE${row}`
         ]
     })
     
    res.json( metaData.data.valueRanges )

}

controller.changeStatus = async ( req, res ) => {

    let row = req.body.row,
        status = req.body.stateChange,
        observations = req.body.observations
        
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "1QHMRqMwOFK_oxmbB8aLP25wAqelCmB2pytCC746CYyc"
   
    data = [
        {           
            range: `Contad!P${row}`,
            values: [[status]]
        },
        {
            range: `Contad!Q${row}`,
            values: [[observations]]
        }
    ]
 
    request = {

        auth,        
        valueInputOption: "RAW",
        resource: { data },
        spreadsheetId
        
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.batchUpdate(request)).data 
        console.log(JSON.stringify(response, null, 2))
        res.json( response )
        
    } catch (err) {
        
        console.error(err)
        res.json( 'error' )

    }
    
    
}

controller.saveVisit1 = async (req, res ) => {
    
    console.log( req.body)
    const { program, eventDate, activity, description, eventInitialHour, eventFinalHour, linkPresentation, linkFolder, linkMeet, linkVideo, observations, visitStatus, row} = req.body
        
        const auth = new google.auth.GoogleAuth({
            keyFile: 'src/json/credentials.json',
            scopes: "https://www.googleapis.com/auth/spreadsheets",
        })
        
        //Creat client instance for auth
        const client = await auth.getClient()
        const googleSheets = google.sheets({version: "v4", auth: client})
        const spreadsheetId = "1QHMRqMwOFK_oxmbB8aLP25wAqelCmB2pytCC746CYyc"
        let dateSplit = eventDate.split('-'),
            dateSaved = `${dateSplit[2]}/${dateSplit[1]}/${dateSplit[0]}`
        

        let request = {
            auth,        
            valueInputOption: "RAW",
            resource: {
                values: [
                    [
                       program,
                       dateSaved,
                       eventInitialHour,
                       description,
                       linkPresentation,
                       linkFolder,
                       linkMeet,
                       eventFinalHour,
                       activity,
                       linkVideo,
                       '',
                       '',
                       '',
                       visitStatus,
                       observations
                    ]
                ]
            },
            spreadsheetId,
            range: `Contad!C${row}:Q${row}`
        }
        
        
        try {
    
            const response = (await googleSheets.spreadsheets.values.update(request)).data 
            res.json( response )
            
        } catch (err) {
            
            res.json( 'error' )
    
        }
}

module.exports = controller