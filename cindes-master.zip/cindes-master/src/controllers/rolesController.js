import { pool } from '../database.js'

export const getOptionsRole = async (req, res) => {

    const { role } = req.body
    
    const sql = `SELECT 

            p.option,
            (SELECT o.view FROM optionMenu o WHERE o.Id = p.option) viewName,
            (SELECT o.icon FROM optionMenu o WHERE o.Id = p.option) icon,
            (SELECT o.name FROM optionMenu o WHERE o.Id = p.option) optionName,
            (SELECT c.category FROM category c WHERE c.Id = (SELECT o.category FROM optionMenu o WHERE o.Id = p.option)) categoryName

        
        FROM permission p 
        
        WHERE  p.role = ?
        ORDER BY categoryName`
    
    let [result] = await pool.query( sql, [role] )
    
    console.log( result )
    res.json(result)

}

export const verifyPermission = async (req, res) => {

            

}
