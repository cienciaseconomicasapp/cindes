
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { SECRET } from '../config.js'
import { pool } from '../database.js'

export const signUp = async (req, res) => {
     
     const {username, password, role, fullname} = req.body
     const salt = await bcrypt.genSalt(10)
     const encryptedPassword = await bcrypt.hash(password, salt)
    
     let sql = `INSERT INTO user(username, password, role, fullname) VALUES(?, ?, ?, ?)`
     
     try {

          let [result] = await pool.query(sql, [username, encryptedPassword, role, fullname])
          res.json(result)

     } catch(error) {

          res.json({error:'cualquier cosa'})
     }


}

export const signIn = async (req, res) => {    

     const username = req.body.signInUsername
     const password = req.body.password     
     
     let sql = `SELECT id, username, password, role, fullname FROM user WHERE username = ?`

     let [result] = await pool.query(sql, [username])

     if( result.length > 0 ) {

         let verify = await bcrypt.compare(password, result[0].password )

         if( verify )  {

               let user = {
                    fullname: result[0].fullname,
                    username,
                    userId: result[0].id
               }
               let token = jwt.sign(user, SECRET, { expiresIn: '8h'})
               res.json({error: false, token, username, fullname: result[0].fullname, role: result[0].role, userId: result[0].id })

         } else {

               res.json({error: true, message: 'La contraseña digitada no es correcta.', color: 'danger'})
          }

      } else {

          res.json({error: true, message: 'El usuario no se encuentra registrado en la base de datos.', color: 'danger'})
     }

    
}

export const changePassword = async(req, res) => {

     const {lastPassword, newPassword, username} = req.body
     
     const auth = new google.auth.GoogleAuth({
          keyFile: 'src/json/credentials.json',
          scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
   
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1spbcKAewmtuHvL3mpHQFBrhxi5Q3GOMVzEZoNtqcEHM"
     
     //Get data about spreadsheets
     const users = await googleSheets.spreadsheets.values.get({
          auth,
          spreadsheetId,
          range: "users!A:E"
     })
    
     let  validatedUser = false,
          userData = [],
          row = 0
          
          
     for( i=0; i < users.data.values.length; i++ )  {
          
          if( users.data.values[i][1] === username && await bcrypt.compare(lastPassword, users.data.values[i][4]) ) {

               row = i + 1
               userData.push( users.data.values[i] )
          }
     }

     if( userData.length > 0 ) {

          let  salt = await bcrypt.genSalt(10),
               newEncryptedPassword = await bcrypt.hash( newPassword, salt ),
               request = {
                    auth,        
                    valueInputOption: "RAW",
                    resource: {
                         values: [ [ newEncryptedPassword ] ]
                    },
                    spreadsheetId,
                    range: `users!E${row}`
               }
           
           
          try {
       
               const response = await googleSheets.spreadsheets.values.update(request)
               res.json( {
                    error: false,
                    message: 'La contraseña se actualizó con éxito.' 
               })
               
           } catch (err) {
               
               res.json( {
                    error: true,
                    message: 'Ocurrió un error al intentar actualizar la contraseña.' 
               })
       
           }

     } else {

          res.json({
               error: true,
               message: "La contraseñ digitada no corresponde a la registrada."
          })

     }

                            
         

}

export const withoutAuthorization = async (req, res) => {
     res.render('withoutAuthorization')

}

export const openChangePasswordForm = (req, res) => {

     res.render('changePassword')
 
}


