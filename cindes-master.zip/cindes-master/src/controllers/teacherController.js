const {google} = require("googleapis")
const controller = {}

controller.page = (req, res) => {

    res.render('teacher')

}


controller.getList = async (req, res) => {

    const { email } = req. body
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1pmLJYR1hJpL1_6-OYImjhE88lo5Ss6iWyTXb7LAW28A"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:S"
     })

    //Agregamos el numero de la fila al final del array de cada item
    metaData.data.values.forEach( (item,index) => {
        metaData.data.values[index].push(index+1)
    })
     
     if( email === '' ) {
    
        res.json( metaData.data.values )

    } else {

        let data = metaData.data.values.filter( item => item[1] === email )
        res.json( data )
    }

}

controller.getRow = async (req, res) => {

    const { row } = req.body;

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1pmLJYR1hJpL1_6-OYImjhE88lo5Ss6iWyTXb7LAW28A"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
        auth,
        spreadsheetId,
        range: `Respuestas de formulario 1!A${row}:S${row}`
     })
    
    console.log(metaData.data.values)
    res.json( metaData.data.values )

}

controller.changeStatus = async ( req, res ) => {

    let row = req.body.row,
        status = req.body.stateChange,
        observations = req.body.observations
        
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "1pmLJYR1hJpL1_6-OYImjhE88lo5Ss6iWyTXb7LAW28A"
   
    data = [
        {           
            range: `Respuestas de formulario 1!P${row}`,
            values: [[status]]
        },
        {
            range: `Respuestas de formulario 1!Q${row}`,
            values: [[observations]]
        }
    ]
 
    request = {

        auth,        
        valueInputOption: "RAW",
        resource: { data },
        spreadsheetId
        
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.batchUpdate(request)).data 
        console.log(JSON.stringify(response, null, 2))
        res.json( response )
        
    } catch (err) {
        
        console.error(err)
        res.json( 'error' )

    }
    
    
}

module.exports = controller