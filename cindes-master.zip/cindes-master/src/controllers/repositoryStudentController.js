const {google} = require("googleapis")
const path = require("path")
const controller = {}

controller.page = (req, res) => {

    res.render('repositoryStudent')

}


controller.getList = async (req, res) => {

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1En67WKhTKFE_JNrnWqY3bYO4T6xpaBEc1WG9z1CmfUg"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:AE"
     })
     
    res.json( metaData.data )

}

controller.getRow = async (req, res) => {

    const { row } = req.body;

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1En67WKhTKFE_JNrnWqY3bYO4T6xpaBEc1WG9z1CmfUg"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.batchGet({
        auth,
         spreadsheetId,
         ranges: [
             'Respuestas de formulario 1!A1:A1',
             `Respuestas de formulario 1!A${row}:AE${row}`
         ]
     })
     
    res.json( metaData.data.valueRanges )

}

controller.changeStatus = async ( req, res ) => {

    let row = req.body.row,
        status = req.body.stateChange,
        observations = req.body.observations
        
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "1En67WKhTKFE_JNrnWqY3bYO4T6xpaBEc1WG9z1CmfUg"
   
    data = [
        {           
            range: `Respuestas de formulario 1!P${row}`,
            values: [[status]]
        },
        {
            range: `Respuestas de formulario 1!Q${row}`,
            values: [[observations]]
        }
    ]
 
    request = {

        auth,        
        valueInputOption: "RAW",
        resource: { data },
        spreadsheetId
        
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.batchUpdate(request)).data 
        console.log(JSON.stringify(response, null, 2))
        res.json( response )
        
    } catch (err) {
        
        console.error(err)
        res.json( 'error' )

    }
    
    
}

module.exports = controller