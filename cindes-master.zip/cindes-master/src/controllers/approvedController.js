const {google} = require("googleapis")
const nodemailer = require('nodemailer');
const path = require("path")
const controller = {}

controller.page = (req, res) => {

    res.render('approved')

}

controller.saveCulminatedStudents = async ( req, res ) => {

    let rows = req.body.row,        
        culminatedCertificate = req.body.culminatedCertificate,
        culminatedCertificateLink = req.body.culminatedCertificateLink        
        culminatedDate = req.body.culminatedDate        
   

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "1iXCqbmojnlDf37B2m56sSNNU_U63j2n1S3Xl7oBtPjo"
    
    let data = []
    rows.forEach( row => {

        data.push(
            {           
                range: `Respuestas de formulario 1!AM${row}:AN${row}`,
                values: [
                    [
                        culminatedCertificate,
                        culminatedCertificateLink
                    ]
                ]           
            },           
            {
                range: `Respuestas de formulario 1!AJ${row}`,
                values: [['Finalizado']]                   
            },
            {
                range: `Respuestas de formulario 1!AY${row}`,
                values: [[culminatedDate]]                   
            }
        )

    })

    request = {
        auth,        
        valueInputOption: "RAW",
        spreadsheetId,
        resource: { data }        
       
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.batchUpdate(request)).data 
        
        sendEmail()
        res.json( response )
        
    } catch (err) {
        
        console.error(err)
        res.json( 'error' )

    }
        
}

function sendEmail() {
    
    let transporter = nodemailer.createTransport({
        Host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        requireTLS: true,
        auth: {
            user: 'contaduria@mail.uniatlantico.edu.co', 
            pass: 'Contaduria0912*'           
        }
    });
        
    let mailOptions = {
        from: 'contaduria@mail.uniatlantico.edu.co',
        to: 'freddymejiatorres@gmail.com',
        subject: 'Check Mail',
        text: 'Its working node mailer'
    };
        
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
                return console.log(error.message);
        }
        console.log('success');
    }); 
}

module.exports = controller