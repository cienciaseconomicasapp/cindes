const {google} = require("googleapis")
const path = require("path")
const controller = {}

controller.page = (req, res) => {

    res.render('endorsed')

}
 

controller.saveApprovedStudents = async ( req, res ) => {

    let rows = req.body.row,        
        approvedCertificate = req.body.approvedCertificate,
        approvedCertificateLink = req.body.approvedCertificateLink,
        approvedDate = req.body.approvedDate
    
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "1iXCqbmojnlDf37B2m56sSNNU_U63j2n1S3Xl7oBtPjo"
    // const spreadsheetId = "1XfIPtPj2Nx4Kt4JGcSHdOWTrNyQBUysIQhaNS3Qo3HY" //test

    let data = []
    rows.forEach( row => {

        data.push(
            {           
                range: `Respuestas de formulario 1!AK${row}:AL${row}`,
                values: [
                    [
                        approvedCertificate,
                        approvedCertificateLink
                    ]
                ]           
            },
            {
                range: `Respuestas de formulario 1!AW${row}`,
                values: [[approvedDate]]
            },
            {
                range: `Respuestas de formulario 1!AJ${row}`,
                values: [['Aprobado']]                   
            }

        )

    })

    request = {
        auth,        
        valueInputOption: "RAW",
        spreadsheetId,
        resource: { data }        
       
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.batchUpdate(request)).data 
        console.log(JSON.stringify(response, null, 2))
        res.json( response )
        
    } catch (err) {
        
        console.error(err)
        res.json( 'error' )

    }
        
}



module.exports = controller