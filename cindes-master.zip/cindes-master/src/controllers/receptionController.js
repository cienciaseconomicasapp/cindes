import { pool } from '../database.js'
import multer from 'multer'

const storage = multer.diskStorage({
    destination: 'src/files',
    filename: (req, file, cb) => {
        console.log(file)
      cb(null, `${Date.now()}-${file.originalname}`);        
    }
});

export const upload = multer({ storage: storage})

export const receptionUpFile = async (req, res) => {

    const { company, file } = req.body
    console.log( company, file )

}

export const page = (req, res) => {

    res.render('reception')

}




export const getList = async (req, res) => {

   
    const sql = `SELECT  
            p.*,
            DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
            FORMAT(p.amount, 0) amountFormat,
            (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
            (SELECT e.name FROM person e WHERE e.Id = p.people) personName,
            (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
            (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
            (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription

        FROM payable p where statusId is null
        `
    
    const [result] = await pool.query( sql )

    console.log(result)
    res.json( result )

}



export const getListCompany = async (req, res) => {

   
    const sql = `SELECT 

            c.Id, 
            c.nit, 
            c.nombre companyName
        FROM company c
        WHERE c.active = 1`
    
    const [result] = await pool.query( sql )

    console.log(result)
    res.json( result )

}

export const getListCenter = async (req, res) => {

   
    const sql = `SELECT 

        c.Id, 
        c.centro centerName
        FROM center c
        WHERE c.active = 1`
    
    const [result] = await pool.query( sql )

    console.log(result)
    res.json( result )

}

export const getListPerson = async (req, res) => {

   
    const sql = `SELECT 

        p.Id, 
        p.name personName
        FROM person p
        WHERE p.active = 1
        ORDER BY personName ASC
    `
    
    const [result] = await pool.query( sql )

    console.log(result)
    res.json( result )

}
