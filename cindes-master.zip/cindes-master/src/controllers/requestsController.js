const {google} = require("googleapis")
const path = require("path")
const controller = {}

controller.page = (req, res) => {

    res.render('requests')
    res.render('requestsQuery')

}

controller.getList = async (req, res) => {

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1iXCqbmojnlDf37B2m56sSNNU_U63j2n1S3Xl7oBtPjo"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:AY"
     })
     
    res.json( metaData.data )

}

controller.getRow = async (req, res) => {

    const { row } = req.body;

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1iXCqbmojnlDf37B2m56sSNNU_U63j2n1S3Xl7oBtPjo"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.batchGet({
        auth,
         spreadsheetId,
         ranges: [
             'Respuestas de formulario 1!A1:A1',
             `Respuestas de formulario 1!A${row}:AX${row}`
         ]
     })
     
    res.json( metaData.data.valueRanges )

}

controller.checkCredits = async ( req, res ) => {

    const { identification, program } = req.body;   
    
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1uU9HW1OySDCm4_HrLsIpOfz-xjQdhJl9NmnfjNYX0DI"
     
     //Get data about spreadsheets "Documento para verificar créditos"
     let metaData = await googleSheets.spreadsheets.values.get({
        auth,
        spreadsheetId,
        range: "Pregrado!A:AU"
        
     })

       
    let filteredData = metaData.data.values.filter( item =>  {
        
        return  item[5] == identification && item[32] == program 
            
    }) 
        

    if( filteredData.length > 0 ) {

        res.json( filteredData )   

    } else {

        metaData = await googleSheets.spreadsheets.values.get({
            auth,
            spreadsheetId,
            range: "Egresados!A:R"
            
        })
        
        filteredData = metaData.data.values.filter( item => {
            
            if( item[0] == identification && item[12] == program ) {
                return true
            } 
        })
        
        res.json( filteredData ) 
        
    }
    

}

controller.changeStatus = async ( req, res ) => {

    
    let row = req.body.row,
        status = req.body.stateChange,
        reasonForRejection = req.body.reasonForRejection,
        endingCertificate = req.body.endingCertificate,
        endingCertificateLink = req.body.endingCertificate,
        approvalCertificate = req.body.approvalCertificate,
        approvalCertificateLink = req.body.approvalCertificateLink,
        culminationIndividualCertificate = req.body.culminationIndividualCertificate,
        culminationIndividualCertificateLink = req.body.culminationIndividualCertificateLink,
        grade1 = req.body.grade1,
        grade2 = req.body.grade2,
        grade3 = req.body.grade3,
        grade4 = req.body.grade4,
        average = req.body.average,
        approvalDate = req.body.approvalDate,
        endorsedSignedDocument = req.body.endorsedSignedDocument,
        endingDate = req.body.endingDate
    
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "1iXCqbmojnlDf37B2m56sSNNU_U63j2n1S3Xl7oBtPjo"
     
    let request = {
        auth,        
        valueInputOption: "RAW",
        resource: {
            values: [
                [
                    status,
                    approvalCertificate,
                    approvalCertificateLink,
                    endingCertificate,
                    endingCertificateLink,
                    culminationIndividualCertificate,
                    culminationIndividualCertificateLink,
                    grade1,
                    grade2,
                    grade3,
                    grade4,
                    average,
                    reasonForRejection,
                    approvalDate,
                    endorsedSignedDocument,
                    endingDate
                ]
            ]
        },
        spreadsheetId,
        range: `Respuestas de formulario 1!AJ${row}:AY${row}`
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.update(request)).data 
        res.json( response )
        
    } catch (err) {
        
        res.json( 'error' )

    }
    
    
}



module.exports = controller