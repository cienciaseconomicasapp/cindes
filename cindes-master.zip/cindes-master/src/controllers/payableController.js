import { pool } from '../database.js'
import multer from 'multer'

const prefix = Date.now()

const storage = multer.diskStorage({
    destination: 'src/public/files',
    filename: (req, file, cb) => {
      cb(null, `${prefix}-${file.originalname}`);        
    }
});

export const upload = multer({ storage })


export const payableUpFile = async (req, res) => {
   
    const { company, center, person, description, amount, } = req.body
    const fileName = prefix + '-' + req.file.originalname

    let sql = `INSERT INTO payable(company, center, person, description, amount, file ) VALUES(?,?,?,?,?,?)`

    try {

        let [result] = await pool.query( sql, [company, center, person, description, amount, fileName])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}

export const createPerson = async (req, res) => {
   
    const { identification, name, } = req.body


    let sql = `INSERT INTO person (identification, name ) VALUES(?,?)`

    try {

        let [result] = await pool.query( sql, [identification, name, ])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}


export const page = (req, res) => {

    res.render('payable')

}

export const accountant = (req, res) => {

    res.render('accountant')

}

export const financial = (req, res) => {

    res.render('financial')

}

export const management = (req, res) => {

    res.render('management')

}

export const treasury = (req, res) => {

    res.render('treasury')

}

export const discharge = (req, res) => {

    res.render('discharge')

}

export const repository = (req, res) => {

    res.render('repository')

}


export const payableForm = (req, res ) => {
    res.render('payableForm')
}

export const personForm = (req, res ) => {
    res.render('personForm')
}

export const person = (req, res ) => {
    res.render('person')
}


export const payableRow = async (req, res) => {

    const { payableId } = req.body

    const sql = `SELECT p.*, DATE_FORMAT(p.date, '%Y-%m-%d') dateFormated FROM payable p WHERE id = ?`    

    try {

        let [result] = await pool.query(sql, [payableId])

        if( result.length > 0 ) {

            res.json({error:false, result})
        }

    } catch(error) {

        res.json({error:true, message:error})
    }

}

export const getList = async (req, res) => {

    const {companySelect, initialDate, finalDate, center, status } = req.body

    let filter = 'p.statusId IN (1, 2, 8)',
        union = ' AND '

    if( companySelect !== '' ) {
        filter += `${union} company = ${companySelect}`
        union = ' AND '

    }

    if( initialDate !== '' && finalDate !== '' ) {
        
        filter += `${union} date BETWEEN '${initialDate}' AND '${finalDate}'`
        union = ' AND '
    }

    if( center !== '' ) {
        filter += `${union} center = ${center}`
        union = ' AND '

    }

    if( status !== '' ) {
        filter += `${union} statusId = ${status}`
        union = ' AND '

    }

  
    filter = filter === '' ? '' :  `WHERE ${filter}`
   
    const sql = `SELECT  
            p.*,
            DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
            FORMAT(p.amount, 0) amountFormat,
            p.file,
            (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
            (SELECT e.name FROM person e WHERE e.Id = p.person) personName,
            (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
            (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
            (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription


        FROM payable p
        
        ${filter}`
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getList3 = async (req, res) => {

    const {companySelect, initialDate, finalDate, center, status } = req.body

    let filter = 'p.statusId IN (1, 3)',
        union = ' AND '

    if( companySelect !== '' ) {
        filter += `${union} company = ${companySelect}`
        union = ' AND '

    }

    if( initialDate !== '' && finalDate !== '' ) {
        
        filter += `${union} date BETWEEN '${initialDate}' AND '${finalDate}'`
        union = ' AND '
    }

    if( center !== '' ) {
        filter += `${union} center = ${center}`
        union = ' AND '

    }

    if( status !== '' ) {
        filter += `${union} statusId = ${status}`
        union = ' AND '

    }

  
    filter = filter === '' ? '' :  `WHERE ${filter}`
   
    const sql = `SELECT  
            p.*,
            DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
            FORMAT(p.amount, 0) amountFormat,
            p.file,
            (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
            (SELECT e.name FROM person e WHERE e.Id = p.person) personName,
            (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
            (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
            (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription


        FROM payable p

        ${filter}`
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getList4 = async (req, res) => {

    const {companySelect, initialDate, finalDate, center, status } = req.body

    let filter = ' p.statusId IN (4, 5)',
        union = ' AND '

    if( companySelect !== '' ) {
        filter += `${union} company = ${companySelect}`
        union = ' AND '

    }

    if( initialDate !== '' && finalDate !== '' ) {
        
        filter += `${union} date BETWEEN '${initialDate}' AND '${finalDate}'`
        union = ' AND '
    }

    if( center !== '' ) {
        filter += `${union} center = ${center}`
        union = ' AND '

    }

    if( status !== '' ) {
        filter += `${union} statusId = ${status}`
        union = ' AND '

    }

  
    filter = filter === '' ? '' :  `WHERE ${filter}`
   
    const sql = `SELECT  
            p.*,
            DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
            FORMAT(p.amount, 0) amountFormat,
            FORMAT(p.txNational+txLocal+advances+othersDiscounts, 0) discounts,
            FORMAT(p.amount-(p.txNational+txLocal+advances+othersDiscounts), 0) netPay,
            p.file,
            p.accountFile,
            (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
            (SELECT e.name FROM person e WHERE e.Id = p.person) personName,
            (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
            (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
            (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription


        FROM payable p


        
        ${filter}`
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getList5 = async (req, res) => {

    const {companySelect, initialDate, finalDate, center, status } = req.body

    let filter = 'p.statusId IN (3, 4)',
        union = ' AND '

    if( companySelect !== '' ) {
        filter += `${union} company = ${companySelect}`
        union = ' AND '

    }



    if( initialDate !== '' && finalDate !== '' ) {
        
        filter += `${union} date BETWEEN '${initialDate}' AND '${finalDate}'`
        union = ' AND '
    }

    if( center !== '' ) {
        filter += `${union} center = ${center}`
        union = ' AND '

    }

    if( status !== '' ) {
        filter += `${union} statusId = ${status}`
        union = ' AND '

    }

  
    filter = filter === '' ? '' :  `WHERE ${filter}`
   
    const sql = `SELECT  
            p.*,
            DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
            FORMAT(p.amount, 0) amountFormat,
            FORMAT(p.txNational+txLocal+advances+othersDiscounts, 0) discounts,
            FORMAT(p.amount-(p.txNational+txLocal+advances+othersDiscounts), 0) netPay,
            p.file,
            p.accountFile,
            (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
            (SELECT e.name FROM person e WHERE e.Id = p.person) personName,
            (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
            (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
            (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription


        FROM payable p
        
        
        ${filter}`
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getList6 = async (req, res) => {

    const {companySelect, initialDate, finalDate, center, status } = req.body

    let filter = 'p.statusId IN (5, 6)',
        union = ' AND '

    if( companySelect !== '' ) {
        filter += `${union} company = ${companySelect}`
        union = ' AND '

    }

    if( initialDate !== '' && finalDate !== '' ) {
        
        filter += `${union} date BETWEEN '${initialDate}' AND '${finalDate}'`
        union = ' AND '
    }

    if( center !== '' ) {
        filter += `${union} center = ${center}`
        union = ' AND '

    }

    if( status !== '' ) {
        filter += `${union} statusId = ${status}`
        union = ' AND '

    }

  
    filter = filter === '' ? '' :  `WHERE ${filter}`
   
    const sql = `SELECT  
            p.*,
            DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
            FORMAT(p.amount, 0) amountFormat,
            FORMAT(p.txNational+txLocal+advances+othersDiscounts, 0) discounts,
            FORMAT(p.amount-(p.txNational+txLocal+advances+othersDiscounts), 0) netPay,
            p.file,
            p.accountFile,
            p.payFile,
            (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
            (SELECT e.name FROM person e WHERE e.Id = p.person) personName,
            (SELECT a.accountBank FROM accountBank a WHERE a.Id = p.accountBank) bankName,
            (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
            (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
            (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription


        FROM payable p
        
        ${filter}`
    
    const [result] = await pool.query( sql )

    res.json( result )


}

export const getList7 = async (req, res) => {

   
    const {companySelect, initialDate, finalDate, center, status } = req.body

    let filter = 'p.statusId IN (6, 10)',
        union = ' AND '

        if( companySelect !== '' ) {
            filter += `${union} company = ${companySelect}`
            union = ' AND '
    
        }
    
    if( initialDate !== '' && finalDate !== '' ) {
        
        filter += `${union} date BETWEEN '${initialDate}' AND '${finalDate}'`
        union = ' AND '
    }

    if( center !== '' ) {
        filter += `${union} center = ${center}`
        union = ' AND '

    }

    if( status !== '' ) {
        filter += `${union} statusId = ${status}`
        union = ' AND '

    }

  
    filter = filter === '' ? '' :  `WHERE ${filter}`
   
    const sql = `SELECT  
            p.*,
            DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
            FORMAT(p.amount, 0) amountFormat,
            FORMAT(p.txNational+txLocal+advances+othersDiscounts, 0) discounts,
            FORMAT(p.amount-(p.txNational+txLocal+advances+othersDiscounts), 0) netPay,
            p.file,
            p.accountFile,
            p.payFile,
            (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
            (SELECT e.name FROM person e WHERE e.Id = p.person) personName,
            (SELECT a.accountBank FROM accountBank a WHERE a.Id = p.accountBank) bankName,
            (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
            (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
            (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription


        FROM payable p

        
        ${filter}`
    
    const [result] = await pool.query( sql )

    res.json( result )


}

export const getList8 = async (req, res) => {

    const {companySelect, initialDate, finalDate, center, status } = req.body

    let filter = '',
        union = ''

    if( companySelect !== '' ) {
        filter += `${union} company = ${companySelect}`
        union = ' AND '

    }

    if( initialDate !== '' && finalDate !== '' ) {
        
        filter += `${union} date BETWEEN '${initialDate}' AND '${finalDate}'`
        union = ' AND '
    }

    if( center !== '' ) {
        filter += `${union} center = ${center}`
        union = ' AND '

    }

    if( status !== '' ) {
        filter += `${union} statusId = ${status}`
        union = ' AND '

    }

  
    filter = filter === '' ? '' :  `WHERE ${filter}`
   
    const sql = `SELECT  
    p.*,
    DATE_FORMAT( p.date, '%Y-%m-%d') payableDate,
    FORMAT(p.amount, 0) amountFormat,
    FORMAT(p.txNational+txLocal+advances+othersDiscounts, 0) discounts,
    FORMAT(p.amount-(p.txNational+txLocal+advances+othersDiscounts), 0) netPay,
    p.file,
    p.accountFile,
    p.payFile,
    (SELECT c.nombre FROM company c WHERE c.Id = p.company) companyName,
    (SELECT e.name FROM person e WHERE e.Id = p.person) personName,
    (SELECT a.accountBank FROM accountBank a WHERE a.Id = p.accountBank) bankName,
    (SELECT s.color FROM status s WHERE s.Id = p.statusId) statusColor,
    (SELECT c.centro FROM center c WHERE c.Id = p.center) centerName,
    (SELECT s.state FROM status s WHERE s.Id = p.statusId) statusDescription


FROM payable p
        
        ${filter}`
    
    const [result] = await pool.query( sql )

    res.json( result )

}


export const getListCompany = async (req, res) => {

   
    const sql = `SELECT 

            c.Id, 
            c.nit, 
            c.nombre companyName
        FROM company c
        WHERE c.active = 1
        order by c.nombre ASC`
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListCenter = async (req, res) => {

   
    const sql = `SELECT 

        c.Id, 
        c.centro centerName
        FROM center c
        WHERE c.active = 1`
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListPerson = async (req, res) => {

   
    const sql = `SELECT 

        p.Id, 
        p.name personName
        FROM person p
        WHERE p.active = 1
        ORDER BY personName ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListAccountBank = async (req, res) => {

   
    const sql = `SELECT 

        a.Id, 
        a.accountBank bankName
        FROM accountBank a
        WHERE a.active = 1
        ORDER BY accountBank ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}


export const getListStatus = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM status p
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}


export const getListStatus1 = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM (status AS p INNER JOIN optionStatus ON p.Id = optionStatus.status) INNER JOIN optionMenu ON optionStatus.option = optionMenu.Id
    WHERE (((optionStatus.option)=1))
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListStatus2 = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM (status AS p INNER JOIN optionStatus ON p.Id = optionStatus.status) INNER JOIN optionMenu ON optionStatus.option = optionMenu.Id
    WHERE (((optionStatus.option)=2))
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListStatus3 = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM (status AS p INNER JOIN optionStatus ON p.Id = optionStatus.status) INNER JOIN optionMenu ON optionStatus.option = optionMenu.Id
    WHERE (((optionStatus.option)=3))
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListStatus4 = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM (status AS p INNER JOIN optionStatus ON p.Id = optionStatus.status) INNER JOIN optionMenu ON optionStatus.option = optionMenu.Id
    WHERE (((optionStatus.option)=4))
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListStatus5 = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM (status AS p INNER JOIN optionStatus ON p.Id = optionStatus.status) INNER JOIN optionMenu ON optionStatus.option = optionMenu.Id
    WHERE (((optionStatus.option)=5))
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListStatus6 = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM (status AS p INNER JOIN optionStatus ON p.Id = optionStatus.status) INNER JOIN optionMenu ON optionStatus.option = optionMenu.Id
    WHERE (((optionStatus.option)=6))
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}

export const getListStatus7 = async (req, res) => {

   
    const sql = `SELECT 
    
    p.Id, 
    p.state statusName
    FROM (status AS p INNER JOIN optionStatus ON p.Id = optionStatus.status) INNER JOIN optionMenu ON optionStatus.option = optionMenu.Id
    WHERE (((optionStatus.option)=7))
    ORDER BY p.Id ASC
    `
    
    const [result] = await pool.query( sql )

    res.json( result )

}


export const payableUpdateFile = async (req, res) => {
    

    const {  observations, statusModal, txNational, txLocal, advances, othersDiscounts, payableId } = req.body
    const accountFile = prefix + '-' + req.file.originalname

    let sql = `UPDATE payable SET  observations = ?, statusId = ?, txNational = ?, txLocal = ?, advances = ?, othersDiscounts = ?, accountFile = ?  WHERE id = ? `

    try {

        let [result] = await pool.query( sql, [ observations, statusModal, txNational, txLocal, advances, othersDiscounts, accountFile, payableId])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}


export const payableEditStatus = async (req, res) => {
    

    const { companyModal, centerModal, personModal, description, observations, amount, statusModal, payableId } = req.body


    let sql = `UPDATE payable SET company = ?, center = ?, person = ?, description = ?, observations = ?, amount = ?, statusId = ?  WHERE id = ? `

    try {

        let [result] = await pool.query( sql, [companyModal, centerModal, personModal, description, observations, amount, statusModal, payableId])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}

export const payableEditFinancial = async (req, res) => {
    

    const {  observations, statusModal, payableId } = req.body


    let sql = `UPDATE payable SET  observations = ?, statusId = ?  WHERE id = ? `

    try {

        let [result] = await pool.query( sql, [ observations, statusModal, payableId])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}

export const payableEditManagement = async (req, res) => {
    

    const {  observations, statusModal, payableId } = req.body


    let sql = `UPDATE payable SET  observations = ?, statusId = ?  WHERE id = ? `

    try {

        let [result] = await pool.query( sql, [ observations, statusModal, payableId])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}

export const payableEditTreasury = async (req, res) => {
    

    const {  observations, statusModal, accountBankModal, payableId } = req.body
    const payFile = prefix + '-' + req.file.originalname

    let sql = `UPDATE payable SET  observations = ?, statusId = ?, payFile = ?, accountBank = ? WHERE id = ? `

    try {

        let [result] = await pool.query( sql, [ observations, statusModal, payFile, accountBankModal, payableId])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}

export const payableEditDischarge = async (req, res) => {
    

    const {  observations, statusModal, payableId } = req.body


    let sql = `UPDATE payable SET  observations = ?, statusId = ?  WHERE id = ? `

    try {

        let [result] = await pool.query( sql, [ observations, statusModal, payableId])
        
        if( result.affectedRows > 0 ) {

            res.redirect( '/success')

        } else {

            res.redirect( '/error')
        }

    } catch( error ) {


        res.redirect( '/error')

    }

}
