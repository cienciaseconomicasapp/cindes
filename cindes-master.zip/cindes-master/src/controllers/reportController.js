const {google} = require("googleapis")
const path = require("path")
const controller = {}

controller.page = (req, res) => {

    res.render('report')

}


controller.getList = async (req, res) => {

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "14DbDK4t8fjymWmTimsfSeVetZzoK7scsHImG0WSKcGo"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:R"
     })
     
    res.json( metaData.data )

}

controller.getUpdate = async (req, res) => {

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "13Tzs9b_mnzhGFv_Y9wIpkF_zWz0KEzpes7ig1zIV3Us"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:R"
     })
     
    res.json( metaData.data )

}

controller.getMinimum = async (req, res) => {

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1qhOvwOBp7vOYN8XWsIILstdnBb2_Y1jSn_p5UODtgOM"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:R"
     })
     
    res.json( metaData.data )

}

controller.getCheck = async (req, res) => {

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "1eOuz1XUje__DSMZTfHXw866pg8dObIv--rJRIBkS-F4"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.get({
         auth,
         spreadsheetId,
         range: "Respuestas de formulario 1!A:R"
     })
     
    res.json( metaData.data )

}

controller.getRow = async (req, res) => {

    const { row } = req.body;

    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
     })
 
     //Creat client instance for auth
     const client = await auth.getClient()
     
     //Instance of Google Sheets API
     const googleSheets = google.sheets({version: "v4", auth: client})
     const spreadsheetId = "14DbDK4t8fjymWmTimsfSeVetZzoK7scsHImG0WSKcGo"
     
     //Get data about spreadsheets
     const metaData = await googleSheets.spreadsheets.values.batchGet({
        auth,
         spreadsheetId,
         ranges: [
             'Respuestas de formulario 1!A1:A1',
             `Respuestas de formulario 1!A${row}:R${row}`
         ]
     })
     
    res.json( metaData.data.valueRanges )

}

controller.changeStatus = async ( req, res ) => {

    let row = req.body.row,
        status = req.body.stateChange,
        observations = req.body.observations,
        leaderAssign = req.body.leaderAssign,
        leaderName = req.body.leaderName
        
    const auth = new google.auth.GoogleAuth({
        keyFile: 'src/json/credentials.json',
        scopes: "https://www.googleapis.com/auth/spreadsheets",
    })
     
    //Creat client instance for auth
    const client = await auth.getClient()

    const googleSheets = google.sheets({version: "v4", auth: client})
    const spreadsheetId = "14DbDK4t8fjymWmTimsfSeVetZzoK7scsHImG0WSKcGo"
     
    request = {
        auth,        
        valueInputOption: "RAW",
        resource: {
            values: [
                [
                    leaderName,
                    leaderAssign,
                    '',
                    status,
                    observations

                ]
            ]
        },
        spreadsheetId,
        range: `Respuestas de formulario 1!L${row}:P${row}`
    }
    
    
    try {

        const response = (await googleSheets.spreadsheets.values.update(request)).data 
        console.log(JSON.stringify(response, null, 2))
        res.json( response )
        
    } catch (err) {
        
        console.error(err)
        res.json( 'error' )

    }
    

    // console.log( metaData.data )
    
}

module.exports = controller