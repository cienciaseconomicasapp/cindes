    const nodemailer = require("nodemailer");
    const path = require("path")
    const config = require('../config')
    const controller = {}

    controller.page = (req, res) => {

        res.render('sendMail')

    }

    controller.sendMail = async (req, res) => {
       
        const { to, subject, message, attachments = [] } = req.body
       
        let transporter = nodemailer.createTransport({
            host: config.HOST,
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
              user: config.MAILUSERNAME,
              pass: config.MAILPASSWORD
            }
        })

        let info
          
        try {
            
            if( attachments.length > 0 ) {

                info = await transporter.sendMail({
                    from: '"OFICINA VIRTUAL" <cienciaseconomicasapp@gmail.com>', // sender address
                    to,
                    subject,
                    attachments,            
                    html: message
                })

            } else {

                info = await transporter.sendMail({
                    from: '"OFICINA VIRTUAL" <cienciaseconomicasapp@gmail.com>', // sender address
                    to,
                    subject,                           
                    html: message
                })
            }            

            res.json({
                sent : true,
                message: `El correo fue enviado a: ${to}`
                
            })

        } catch (err) {
           
            res.json({
                sent : false,
                message: `El correo no fue enviado, ${err}`                
            })
            
        }
        
    }  

module.exports = controller