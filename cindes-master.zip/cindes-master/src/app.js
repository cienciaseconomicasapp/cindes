import express from 'express'
import expressLayouts from 'express-ejs-layouts'
import { dirname, join } from 'path'
import {fileURLToPath} from 'url'

import morgan from 'morgan'

const app = express()
const __dirname = dirname( fileURLToPath(import.meta.url) )

//Import Routes
import payableRoutes from './routes/payableRouter.js'
import receptionRoutes from './routes/receptionRouter.js'
import homeRouter from './routes/homeRouter.js'
import authRouter from './routes/auth.routes.js'
import rolesRouter from './routes/roles.routes.js'
import nodemon from 'nodemon'


//Settings
app.set('port', process.env.PORT || 3000)
app.set('views', join( __dirname, 'views'))
app.set('view engine', 'ejs')

//middleware
app.use(morgan('dev'))
app.use(expressLayouts)
app.use(express.urlencoded({ extended: true }))
app.use(express.json())

//Routes
app.use('/', payableRoutes)
app.use('/', receptionRoutes)
app.use('/', homeRouter)
app.use('/', authRouter)
app.use('/', rolesRouter)


//static files
app.use(express.static(join( __dirname, 'public')))

//Ejecute server
app.listen( app.get('port'), ()=> {
    console.log('server on port 3000')
})