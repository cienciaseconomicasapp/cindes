const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const endorsedController = require('../controllers/endorsedController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/endorsed', endorsedController.page )
router.post('/saveApprovedStudents', verifyToken, endorsedController.saveApprovedStudents )


module.exports = router