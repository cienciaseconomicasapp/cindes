const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const reportQueryController = require('../controllers/reportQueryController')


router.get('/reportQuery', reportQueryController.page )
router.post('/reportQueryList', reportQueryController.getList )
router.post('/reportQueryRow', reportQueryController.getRow )
router.post('/reportQueryChangeStatus', reportQueryController.changeStatus )

module.exports = router