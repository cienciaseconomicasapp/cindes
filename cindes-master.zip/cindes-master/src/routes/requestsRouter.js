const express = require('express')
const app = express()
const router = express.Router()
const requestController = require('../controllers/requestsController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/requests', requestController.page )
router.post('/requestsList', verifyToken, requestController.getList )
router.post('/requestsRow', verifyToken, requestController.getRow )
router.post('/checkCredits', verifyToken, requestController.checkCredits)
router.post('/changeStatus', verifyToken, requestController.changeStatus)


module.exports = router