const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const proposalController = require('../controllers/proposalController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/proposal', proposalController.page )
router.post('/proposalList', verifyToken, proposalController.getList )
router.post('/updateProposalList', verifyToken, proposalController.getUpdate )
router.post('/checkProposalList', verifyToken, proposalController.getCheck )
router.post('/minimumRequirementsList', verifyToken, proposalController.getMinimum )
router.post('/proposalRow', verifyToken, proposalController.getRow )
router.post('/proposalChangeStatus', verifyToken, proposalController.changeStatus )

module.exports = router