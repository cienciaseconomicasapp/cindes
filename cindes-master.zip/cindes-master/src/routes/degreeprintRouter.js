const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const degreeprintController = require('../controllers/degreeprintController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/degreeprint', degreeprintController.page )
router.post('/degreeprintList', verifyToken, degreeprintController.getList )
router.post('/degreeprintRow', verifyToken, degreeprintController.getRow )
router.post('/degreeprintChangeStatus', verifyToken, degreeprintController.changeStatus )

module.exports = router