const express = require('express')
const router = express.Router()
const verifyToken = require('../middlewares/verifyToken')

const mailerController = require('../controllers/mailerController')
router.get('/mailer', mailerController.page )
router.post('/sendMail', verifyToken, mailerController.sendMail )


module.exports = router