const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const visit1Controller = require('../controllers/visit1Controller')
const verifyToken = require('../middlewares/verifyToken')

router.get('/visit1', visit1Controller.page )
router.post('/visit1List', verifyToken, visit1Controller.getList )
router.post('/visit1Row', verifyToken, visit1Controller.getRow )
router.post('/visit1ChangeStatus', verifyToken, visit1Controller.changeStatus )
router.post('/saveVisit1', verifyToken, visit1Controller.saveVisit1 )

module.exports = router