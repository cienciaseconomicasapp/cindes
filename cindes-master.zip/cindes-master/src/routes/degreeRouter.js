const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const degreeController = require('../controllers/degreeController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/degree', degreeController.page )
router.post('/degreeList', verifyToken, degreeController.getList )
router.post('/degreeRow', verifyToken, degreeController.getRow )
router.post('/degreeChangeStatus', verifyToken, degreeController.changeStatus )

module.exports = router