const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const bondingController = require('../controllers/bondingController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/bonding', bondingController.page )
router.post('/bondingList', verifyToken, bondingController.getList )
router.post('/updatebondingList', verifyToken, bondingController.getUpdate )
router.post('/checkbondingList', verifyToken, bondingController.getCheck )
router.post('/minimumRequirementsList', verifyToken, bondingController.getMinimum )
router.post('/bondingRow', verifyToken, bondingController.getRow )
router.post('/bondingChangeStatus', verifyToken, bondingController.changeStatus )

module.exports = router