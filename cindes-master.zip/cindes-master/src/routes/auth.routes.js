import { Router } from 'express'
const router = Router()

//import  verifyToken from '../middlewares/verifyToken.js'

import { changePassword, openChangePasswordForm, signIn, signUp, withoutAuthorization } from '../controllers/authController.js'

router.post('/signUp', signUp )
router.post('/signIn', signIn )
router.get('/withoutAuthorization', withoutAuthorization )
router.get('/openChangePasswordForm', openChangePasswordForm )
router.post('/changePassword', changePassword )

export default router