const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const approvedController = require('../controllers/approvedController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/approved', approvedController.page )
router.post('/saveCulminatedStudents', verifyToken, approvedController.saveCulminatedStudents )


module.exports = router