import { Router } from 'express'
const router = Router()

import { error, home, login, success }  from '../controllers/homeController.js'
router.get('/', login )
router.get('/home', home )
router.get('/success', success )
router.get('/error', error )

export default router