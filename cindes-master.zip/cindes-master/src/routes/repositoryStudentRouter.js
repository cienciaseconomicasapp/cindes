const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const repositoryStudentController = require('../controllers/repositoryStudentController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/repositoryStudent', repositoryStudentController.page )
router.post('/repositoryStudentList', verifyToken, repositoryStudentController.getList )
router.post('/repositoryStudentRow', verifyToken, repositoryStudentController.getRow )
router.post('/repositoryStudentChangeStatus', verifyToken, repositoryStudentController.changeStatus )

module.exports = router