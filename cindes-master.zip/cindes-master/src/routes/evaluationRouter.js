const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const evaluationController = require('../controllers/evaluationController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/evaluation', evaluationController.page )
router.post('/evaluationList', verifyToken, evaluationController.getList )
router.post('/evaluationRow', verifyToken, evaluationController.getRow )
router.post('/evaluationChangeStatus', verifyToken, evaluationController.changeStatus )

module.exports = router