const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const repositoryController = require('../controllers/repositoryController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/repository', repositoryController.page )
router.post('/repositoryList', verifyToken, repositoryController.getList )
router.post('/repositoryRow', verifyToken, repositoryController.getRow )
router.post('/repositoryChangeStatus', verifyToken, repositoryController.changeStatus )

module.exports = router