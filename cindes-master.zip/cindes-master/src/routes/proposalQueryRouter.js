const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const proposalQueryController = require('../controllers/proposalQueryController')


router.get('/proposalQuery', proposalQueryController.page )
router.post('/proposalQueryList', proposalQueryController.getList )
router.post('/proposalQueryRow', proposalQueryController.getRow )
router.post('/proposalQueryChangeStatus', proposalQueryController.changeStatus )

module.exports = router