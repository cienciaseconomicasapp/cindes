const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const performanceController = require('../controllers/performanceController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/performance', performanceController.page )
router.post('/performanceList', verifyToken, performanceController.getList )
router.post('/performanceRow', verifyToken, performanceController.getRow )
router.post('/performanceChangeStatus', verifyToken, performanceController.changeStatus )

module.exports = router