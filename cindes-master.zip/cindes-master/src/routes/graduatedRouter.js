const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const graduatedController = require('../controllers/graduatedController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/graduated', graduatedController.page )
router.post('/graduatedList', verifyToken, graduatedController.getList )
router.post('/graduatedRow', verifyToken, graduatedController.getRow )
router.post('/graduatedChangeStatus', verifyToken, graduatedController.changeStatus )

module.exports = router