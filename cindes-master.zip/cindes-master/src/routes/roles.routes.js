import { Router } from 'express'
const router = Router()

import { getOptionsRole, verifyPermission } from '../controllers/rolesController.js'
import { verifyToken } from '../middlewares/verifyToken.js'

router.post('/getOptionsRole', verifyToken, getOptionsRole )
router.post('/verifyPermission', verifyToken, verifyPermission )

export default router