const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const autonomousController = require('../controllers/autonomousController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/autonomous', autonomousController.page )
router.post('/autonomousList', verifyToken, autonomousController.getList )
router.post('/autonomousRow', verifyToken, autonomousController.getRow )
router.post('/autonomousChangeStatus', verifyToken, autonomousController.changeStatus )

module.exports = router