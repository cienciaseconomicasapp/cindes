const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const requestsQueryController = require('../controllers/requestsQueryController')


router.get('/requestsQuery', requestsQueryController.page )
router.post('/requestsQueryList', requestsQueryController.getList )
router.post('/requestsQueryRow', requestsQueryController.getRow )
router.post('/requestsQueryChangeStatus', requestsQueryController.changeStatus )

module.exports = router