const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const reportController = require('../controllers/reportController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/report', reportController.page )
router.post('/reportList', verifyToken, reportController.getList )
router.post('/updatereportList', verifyToken, reportController.getUpdate )
router.post('/checkreportList', verifyToken, reportController.getCheck )
router.post('/minimumRequirementsList', verifyToken, reportController.getMinimum )
router.post('/reportRow', verifyToken, reportController.getRow )
router.post('/reportChangeStatus', verifyToken, reportController.changeStatus )

module.exports = router