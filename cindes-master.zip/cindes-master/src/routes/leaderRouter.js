const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const leaderController = require('../controllers/leaderController')
const verifyToken = require('../middlewares/verifyToken')

router.post('/leaderList', verifyToken, leaderController.getList )
router.post('/leaderRow', verifyToken, leaderController.getRow )

module.exports = router