const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const syllabusController = require('../controllers/syllabusController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/syllabus', syllabusController.page )
router.post('/syllabusList', verifyToken, syllabusController.getList )
router.post('/syllabusRow', verifyToken, syllabusController.getRow )
router.post('/syllabusChangeStatus', verifyToken, syllabusController.changeStatus )

module.exports = router