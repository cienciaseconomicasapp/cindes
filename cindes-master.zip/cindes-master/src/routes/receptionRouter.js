import { Router } from 'express'
const router = Router()

import { page, getList, getListCompany, getListCenter, getListPerson, receptionUpFile, upload } from  '../controllers/receptionController.js'
//import  { verifyToken } from  '../middlewares/verifyToken.js'

router.get('/reception', page )
router.post('/receptionList', getList )
router.post('/receptionListCompany', getListCompany )
router.post('/receptionListCenter', getListCenter )
router.post('/receptionListPerson', getListPerson )
router.post('/receptionUpFile', upload.single('file'), receptionUpFile )

export default router