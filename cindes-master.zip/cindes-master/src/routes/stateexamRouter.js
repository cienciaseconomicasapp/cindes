const express = require('express')
const app = express()
const router = express.Router()
const stateexamController = require('../controllers/stateexamController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/stateexam', stateexamController.page )
router.post('/stateexamList', verifyToken, stateexamController.getList )
router.post('/stateexamRow', verifyToken, stateexamController.getRow )
router.post('/checkCredits', verifyToken, stateexamController.checkCredits)
router.post('/stateexamchangeStatus', verifyToken, stateexamController.changeStatus)


module.exports = router