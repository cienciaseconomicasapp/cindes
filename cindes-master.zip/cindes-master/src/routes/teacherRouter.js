const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const teacherController = require('../controllers/teacherController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/teacher', teacherController.page )
router.post('/teacherList', verifyToken, teacherController.getList )
router.post('/teacherRow', verifyToken, teacherController.getRow )
router.post('/teacherChangeStatus', verifyToken, teacherController.changeStatus )

module.exports = router