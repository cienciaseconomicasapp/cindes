const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const visitController = require('../controllers/visitController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/visit', visitController.page )
router.post('/visitList', verifyToken, visitController.getList )
router.post('/visitRow', verifyToken, visitController.getRow )
router.post('/visitChangeStatus', verifyToken, visitController.changeStatus )
router.post('/saveVisit', verifyToken, visitController.saveVisit )

module.exports = router