const express = require('express')
const app = express()
const router = express.Router()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
const bondingQueryController = require('../controllers/bondingQueryController')


router.get('/bondingQuery', bondingQueryController.page )
router.post('/bondingQueryList', bondingQueryController.getList )
router.post('/bondingQueryRow', bondingQueryController.getRow )
router.post('/bondingQueryChangeStatus', bondingQueryController.changeStatus )

module.exports = router