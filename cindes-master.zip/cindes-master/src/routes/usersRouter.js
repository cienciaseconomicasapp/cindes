const express = require('express')
const app = express()
const router = express.Router()
const usersController = require('../controllers/usersController')
const verifyToken = require('../middlewares/verifyToken')

router.get('/users', usersController.page )
router.post('/getUsers', verifyToken, usersController.getUsers )
router.post('/getUser', verifyToken, usersController.getUser )
router.post('/updateUser', verifyToken, usersController.updateUser )
router.post('/removeUser', verifyToken, usersController.removeUser)
router.post('/getTeacherUsers', verifyToken, usersController.getTeacherUsers)

module.exports = router