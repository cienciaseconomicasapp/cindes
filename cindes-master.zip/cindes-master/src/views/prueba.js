// Crear la conexión a la base de datos
const connection = mysql.createConnection({
    host: 'localhostcontainers-us-west-52.railway.app',
    user: 'root',
    password: 'XKzqDyTZJQby4TUBgXNQ',
    database: 'railway'
  });
  
  // Crear una instancia de la aplicación Express
  const app = express();
  
  // Ruta para obtener los datos de la tabla y enviar el select como respuesta
  app.get('/datos', (req, res) => {
    const query = 'SELECT nit, nombre FROM company';
    connection.query(query, (error, results) => {
      if (error) throw error;
  
      // Crear el select HTML con las opciones de la tabla
      let selectHTML = '<select>';
      results.forEach(row => {
        selectHTML += `<option value="${row.nit}">${row.nombre}</option>`;
      });
      selectHTML += '</select>';
  
      // Enviar el select como respuesta
      res.send(selectHTML);
    });
  });
  
  // Iniciar el servidor
  app.listen(3000, () => {
    console.log('Servidor iniciado en el puerto 3000');
  });