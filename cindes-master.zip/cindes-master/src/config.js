export const SECRET = '^nhFo&CMHxwZ$4$SaE4X'

