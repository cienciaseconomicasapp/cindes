import jwt from  'jsonwebtoken'


export const verifyToken = async (req, res, next) => {
    
    
    next()
}

export const validateRole = async( req, res, next) => {

    
}
