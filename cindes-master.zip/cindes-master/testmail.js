const nodemailer = require('nodemailer');

let transporter = nodemailer.createTransport({
Host: 'smtp.gmail.com',
port: 587,
secure: false,
requireTLS: true,
auth: {
    user: 'aplicacioncindes@gmail.com', 
    pass: 'Cindes694*'           
}
});

let mailOptions = {
 from: 'aplicacioncindes@gmail.com',
 to: 'alfredoanguila@gmail.com',
 subject: 'Check Mail',
 text: 'Its working node mailer'
};

transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
     return console.log(error.message);
  }
console.log('success');
}); 